<?php
$servidor=mysqli_connect("localhost","root","") or die ("Imposible conectar con el servidor");
$db = "system innovation"; //Base de datos
$conexion= mysqli_select_db($servidor,$db);
session_start();
error_reporting(0);
?>

<!DOCTYPE html>

<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>

   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
        
    
    
    
</head>
<body>
  <br><br>
<h1 style="color: white; position: absolute; top: 0; left: 0; width: 100%; text-align: center;">Sastrerias registradas</h1>


<a href="administracion.php" id="atras-btn">Atrás</a>
<style>
  /* === Google Font Import - Poppins === */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

*{

  
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}

body{
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #272624;
}




.swiper {
  width: 100%; /* Ajusta el ancho máximo del contenedor */
  max-width: 1900px; /* Ancho máximo */
  margin: 50px auto 0; /* Centra horizontalmente el contenedor y agrega margen superior */
}

.swiper-slide.card {
  width: 100%; /* Ajusta el ancho de las tarjetas */
  max-width: 800px; /* Ancho máximo */
  margin: 10px auto; /* Centra horizontalmente las tarjetas y agrega espacio entre ellas */
}




.card{
  position: relative;
  background: #ffffff;
  border-radius: 20px;
  margin: 20px 0;
  box-shadow: 0 5px 10px #10fff3;
}

.card::before{
  content: "";
  position: absolute;
  height: 30%;
  width: 100%;
  background: #07c0ca;
  border-radius: 20px 20px 0 0;
}

.card .card-content{
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 30px;
  position: relative;
  z-index: 70;
}

section .card .image{
  height: 140px;
  width: 140px;
  border-radius: 50%;
  padding: 3px;
  background: rgb(255, 255, 255);
}

section .card .image img{
  height: 100%;
  width: 100%;
  object-fit: cover;
  border-radius: 50%;
  border: 3px solid rgb(255, 255, 255);
}

.card .media-icons{
  position: absolute;
  top: 10px;
  right: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.card .media-icons i{
  color: rgb(201, 29, 29);
  opacity: 0.6;
  margin-top: 10px;
  transition: all 0.3s ease;
  cursor: pointer;
}

.card .media-icons i:hover{
  opacity: 1;
}

.card .name-profession{
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 10px;
  color:#272624;
} 

.name-profession .name{
  font-size: 20px;
  font-weight: 600;
}

.name-profession .profession{
  font-size:15px;
  font-weight: 500;
}

.card .rating{
  display: flex;
  align-items: center;
  margin-top: 18px;
}

.card .rating i{
  font-size: 18px;
  margin: 0 2px;
  color: #13b5dd;
}

.card .button{
  width: 100%;
  display: flex;
  justify-content: space-around;
  margin-top: 20px;
}

.card .button button{
  background: #e82a2a;
  outline: none;
  border: none;
  color: rgb(133, 45, 45);
  padding: 8px 22px;
  border-radius: 20px;
  font-size: 14px;
  transition: all 0.3s ease;
  cursor: pointer;
}

.button button:hover{
  background: #d01616;
}

.swiper-pagination{
  position: absolute;
}





      
body{
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-image: url('administrador/fondocalificacion.jpg'); /* Agrega la URL de tu imagen */
  background-size: cover; /* Ajusta el tamaño de la imagen para cubrir toda la página */
  background-repeat: no-repeat; /* Evita que la imagen se repita */
  background-attachment: fixed; /* Fija la imagen en la ventana del navegador */
}

  #atras-btn {
            position: fixed;
            bottom: 20px;
            right: 50px;
            background-color: coral;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        #atras-btn:hover {
            background-color: #ff8c00;
        }
        
        #visitar-btn {
    display: block; /* Hacer que el enlace sea un bloque */
    width: 100px; /* Ancho del botón */
    margin: 0 auto; /* Centrar horizontalmente */
    text-align: center; /* Alinear texto al centro */
    background-color: blue;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

        #visitar-btn:hover {
            background-color: #ff8c00;
        }
     
</style>
 
  <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

  
  <script>
    var swiper = new Swiper(".mySwiper", {
      slidesPerView: 3,
      spaceBetween: 30,
      slidesPerGroup: 3,
      loop: true,
      loopFillGroupWithBlank: true,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  </script>


  <section>
                                   
  <div class="swiper-wrapper content">
  <?php
  $direccion= $_SESSION["direccionsastreria"];
  $idusuario=$_SESSION["id"];
  
   //visualizacion
$versastrerias = "select * from registrosastreria where idsastrero='$idusuario'";
$queryresultado = mysqli_query($servidor,$versastrerias);
while ($regsastreriasid = mysqli_fetch_array($queryresultado)){ 
  
  
                                ?>
                                
        <div class="swiper-slide card">
          <div class="card-content">
            <div class="image">
            <img src="logoempresa.jpg" alt=""> 
            </div>
            
            <div class="media-icons">
            </div>

            <div class="name-profession">
              <span class="name">

              <?php
                echo $regsastreriasid['nombresastreria']."<br>";
                echo $direccion;
            
                $coordenada=$regsastreriasid['coordenada'];
              
                ?>
<br><br>
<a href="<?php echo $regsastreriasid['coordenadas']?>?" id="visitar-btn">Visitar</a>
                <?php
              
                }
              ?>           
           

            <div class="button">
             
              <br>
              
            </div>
          </div>
        </div>