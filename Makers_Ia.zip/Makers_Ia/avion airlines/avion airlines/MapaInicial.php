<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="mapa.css">
    <header>

        </ul>
    </header>

</head>
<body>
    
    <img src="logo aplicacion.png" alt="Logo de Modistería" style="width:150px;height:200px;position: fixed;top:20px;l;z-index:9999999">



 


        
            <div id="search-btn" class="fas fa-search"></div>
            <div id="login-btn" class="fas fa-user"></div>
        </div>

    </div>

   







    <div id="close-login-btn" class="fas fa-times"></div>

   

</div>




<section class="featured" id="featured">

 
    
    <div class="swiper featured-slider">

        <div class="swiper-wrapper">

            <div class="swiper-slide box">
             
                <div class="image">
                    <img src="local1.png" alt="">
                </div>
                <div class="content">
                    <h3>Sastreria Rengifo</h3>
                    
                    <a href="https://maps.app.goo.gl/kxrQwK5NxEJAP2VY8" class="btn">Sastreria</a>
                </div>
            </div>

            <div class="swiper-slide box">
               
                <div class="image">
                    <img src="" alt="">
                </div>
                <div class="content">
                    <h3><a href=""></a>a</h3>
                    
                    <a href="" class="btn">Sastreria</a>
                </div>
            </div>

            <div class="swiper-slide box">
                
                <div class="image">
                    <img src="" alt="">
                </div>
                <div class="content">
                    <h3>a</h3>
                   
                    <a href="" class="btn">a</a>
                </div>
            </div>

            <div class="swiper-slide box">
               
                <div class="image">
                    <img src="" alt="">
                </div>
                <div class="content">
                    <h3>a</h3>
                    
                    <a href="" class="btn">c</a>
                </div>
            </div>

            <div class="swiper-slide box">
               
                <div class="image">
                    <img src="" alt="">
                </div>
                <div class="content">
                    <h3>ia</h3>
                    
                    <a href="" class="btn">c</a>
                </div>
            </div>

            <div class="swiper-slide box">
                
                <div class="image">
                    <img src="" alt="">
                </div>
                <div class="content">
                    <h3></h3>
                    
                    <a href="" class="btn">c</a>
                </div>
            </div>

            <div class="swiper-slide box">
                
                <div class="image">
                    <img src="" alt="">
                </div>
                <div class="content">
                    <h3>a</h3>
                    
                    <a href="" class="btn">c</a>
                </div>
            </div>

            <div class="swiper-slide box">
           
                <div class="image">
                    <img src="" alt="">
                </div>
                <div class="content">
                    <h3>a</h3>
    
                    <a href="" class="btn">c</a>
                </div>
            </div>

            <div class="swiper-slide box">
            
                <div class="image">
                    <img src="" alt="">
                </div>
                <div class="content">
                    <h3>a</h3>
                
                    <a href="" class="btn">c</a>
                </div>
            </div>

            <div class="swiper-slide box">
           
                <div class="image">
                    <img src="" alt="">
                </div>
                <div class="content">
                    <h3>a</h3>
                    
                    <a href="" class="btn">c</a>
                </div>
            </div>

        </div>

        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

    </div>

</section>
<a href="administracion.php" id="atras-btn">atras</a>
    



<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="script.js"></script>

</body>
</html>