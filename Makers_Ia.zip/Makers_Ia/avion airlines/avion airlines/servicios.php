<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=<!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>STITCHWORK</title>
    </head>
<body>
    
    <style>

            
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
          
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            align-content: center 20px;
            position: relative;
            z-index: 2;

        }

        header img {
            height: 150px;
        }

        .logo {
            font-size: 30px;
            
        }

        .content {
            display: flex;
            justify-content: space-between;
            padding: 20px;
            position: relative;
            z-index: 2;
        }

        .box {
            flex: 1;
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            margin: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .primer{
         text-align: center;
         width: 90%;
        }
        #fondo{
            width: 100%;
            height: 100%;
            position: fixed;
            z-index: 1;
            top: 0px;
            left: 0px;
        }

       
    </style>

    <header>
        <img src="stitch.png" alt="Dressmaker Logo">
        <div class="primer" >STITCH WORK </div>
    </header>
    <div class="content">
        <div class="box">
            
            <h2>Productos y servicios de una sasteria</h2>
            <p>Prendas confeccionadas a medida: trajes, pantalones, camisas, chaquetas, faldas,vestidos,etc.

                Los sastres llevan a cabo todas las tareas de producción de las prendas terminadas, por ejemplo, el patronaje, el corte, la costura, el montaje y el prensado. Los sastres confeccionan por encargo prendas a medida cosidas a mano. También hacen arreglos a prendas como trajes y abrigos.
            </p>
        </div>
        <div class="box">
            <h2>Arreglos de ropa</h2>
            <p>Arreglos de trajes, pantalones, camisas, chaquetas, faldas, vestidos, etc.

                Algunas de las herramientas de sastrería más comunes incluyen las siguientes: tijeras, herramientas de medición, agujas e hilo, alfileres y alfileteros, desgarrador de costuras, tiza de sastre o rotuladores, etc.
            </p>
        </div>
 
    </style>
  
<div style="position: fixed; bottom: 10px; left: 10px;">
   
     
   
<a href="https://twitter.com/Systeminovation">
        <img src="twiter.png" alt="Twitter" width="30" height="30">
  
 <a href="https://www.instagram.com/system_inovattion/">
        <img src="ig.png" alt="Instagram" width="30" height="30">
    
    <a href="https://api.whatsapp.com/send/?phone=3053796931&text&type=phone_number&app_absent=0">
        <img src="what.png" alt="WhatsApp" width="30" height="30"> 
    
</div>


<a href="index.php" id="atras-btn">atras</a>

     <a href="quienes_somos.php" id="info-btn">¿QUIENES SOMOS?</a>  


<style>
      
        #atras-btn {
            position: fixed;
            bottom: 20px;
            right: 50px;
            background-color: coral;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
          }  #atras-btn:hover {
            background-color: #ff8c00;
          }
          #info-btn {
            position: fixed;
            bottom: 20px;
            left: 550px;
            background-color: coral;
            color: white;
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            align:center;
            font-size: 25px;
            cursor: pointer;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
          }  #atras-btn:hover {
            background-color: #ff8c00;
          }
</style>

        
    </div>
    <img src="modisteria-2.jpg" id="fondo">

 
    
</body>
</html>