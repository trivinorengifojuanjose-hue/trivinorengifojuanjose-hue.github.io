<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <br><br>
    <div style="background-color: yellow;width: 100px;height: 100px;" id="uno 
    <br>
    onclick="cambiadecolor ('uno')">s</div><br><br>
    <div style="background-color: yellow;width: 100px;height: 100px;" id="dos"
    onclick="cambiadecolor ('dos')">s</div><br><br>
    <div style="background-color: yellow;width: 100px;height: 100px;" id="tres"
    onclick="cambiadecolor ('tres')">s</div><br><br>    
</body>
</html>


