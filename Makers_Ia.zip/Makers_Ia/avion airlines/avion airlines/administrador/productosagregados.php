<?php
session_start();
$conexion = mysqli_connect('localhost', 'root', '', 'system innovation');
$select = "SELECT * FROM productos";
$result = $conexion->query($select);




?>