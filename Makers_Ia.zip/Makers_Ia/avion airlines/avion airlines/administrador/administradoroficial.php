<?php
session_start();
echo "idsastrero".$_SESSION["id"];

error_reporting(0);
$servidor=mysqli_connect("localhost","root","") or die ("Imposible conectar con el servidor");
$db = "system innovation"; //Base de datos
$conexion= mysqli_select_db($servidor,$db);
?>
<doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
        <title>Pagina administrativa</title>
	    
        <link rel="stylesheet" href="css/bootstrap.min.css">
	    
        <link rel="stylesheet" href="css/administradoroficial.css">
		
		
		
	    <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
	
	
      <link href="https://fonts.googleapis.com/css2?family=Material+Icons"rel="stylesheet">

  </head>
  <body>
  


<div class="wrapper">
     
	  <div class="body-overlay"></div>
	 
	 <div id="sidebar">
	    <div class="sidebar-header">
		   <h3><img src="img/app.jpg" class="img-fluid"/><span>Stich Work</span></h3>
		</div>
		<ul class="list-unstyled component m-0">
		  <li class="">
		  <li> <?php echo $_SESSION["nombredeusuario"]=""; ?></li>
		  <a href="#" class="dashboard"><i class="material-icons">dashboard</i>Inicio</a>
		  </li>
		  
		 
		  
		  
		  
		  
		   <li class="dropdown">
		  <a href="#homeSubmenu4" data-toggle="collapse" aria-expanded="false" 
		  class="dropdown-toggle">
		  <i class="material-icons">extension</i>Reseñas
		  </a>
		  <ul class="collapse list-unstyled menu" id="homeSubmenu4">
		     <li><a href="Calificacion.php">Mirar reseñas</a></li>

		  </ul>
		  </li>
		  
		   <li class="dropdown">
		  <a href="#homeSubmenu5" data-toggle="collapse" aria-expanded="false" 
		  class="dropdown-toggle">
		  <i class="material-icons">border_color</i>Registrar sastreria
		  </a>
		  <ul class="collapse list-unstyled menu" id="homeSubmenu5">
		     <li><a href="registro.php">Formulario de registro</a></li>
			 <li><a href="https://www.google.com/maps/d/embed?mid=1qCOMqVkLrVzYM_9KD7g_FcvPAWVd11Y&ehbc=2E312F">mapa</a></li>
		  </ul>
		
		  
	 </div>
	 
   
   
   
   
      
   
      <div id="content">
	     
		 
		  <div class="top-navbar">
		     <div class="xd-topbar">
			     <div class="row">
				     <div class="col-2 col-md-1 col-lg-1 order-2 order-md-1 align-self-center">
					    <div class="xp-menubar">
						    <span class="material-icons text-white">signal_cellular_alt</span>
						</div>
					 </div>
					 
					 <div class="col-md-5 col-lg-3 order-3 order-md-2">
					     <div class="xp-searchbar">
						     <form>
							    <div class="input-group">
								  <input type="search" class="form-control"
								  placeholder="Search">
								  <div class="input-group-append">
								     <button class="btn" type="submit" id="button-addon2">Go
									 </button>
								  </div>
								</div>
							 </form>
						 </div>
					 </div>
					 
					 
					 <div class="col-10 col-md-6 col-lg-8 order-1 order-md-3">
					     <div class="xp-profilebar text-right">
						    <nav class="navbar p-0">
							   <ul class="nav navbar-nav flex-row ml-auto">
							   <li class="dropdown nav-item active">
							 
								
							   
							  
							   
							   <li class="dropdown nav-item">
							     <a class="nav-link" href="#" data-toggle="dropdown">
								  <img src="img/fondo.jpg" style="width:40px; border-radius:50%;"/>
								  <span class="xp-user-live"></span>
								 </a>
								  <ul class="dropdown-menu small-menu">
								     <li><a href="../Perfil2.php">
									 <span class="material-icons">person_outline</span>
									 Profile
									 </a></li>
									
									 </a></li>
									 <li><a href="../iniciosesionadmi.php">
    <span class="material-icons">logout</span>
    Logout
</a>
									 
								  </ul>
							   </li>
							   
							   
							   </ul>
							</nav>
						 </div>
					 </div>
					 
				 </div>
				 
				 <div class="xp-breadcrumbbar text-center">
				    <h4 class="page-title">Inicio</h4>
					<ol class="breadcrumb">
					  <li class="breadcrumb-item"><a href="#"></a>Perfil</li>
					  <li class="breadcrumb-item active" aria-curent="page">Tabla</li>
					</ol>
				 </div>
				 
				 
			 </div>
		  </div>
		  
		     
		      <div class="main-content">
			     <div class="row">
				    <div class="col-md-12">
					   <div class="table-wrapper">
					     
					   <div class="table-title">
					     <div class="row">
						     <div class="col-sm-6 p-0 flex justify-content-lg-start justify-content-center">
							    <h2 class="ml-lg-2">Tabla de clientes</h2>
							 </div>
							 <div class="col-sm-6 p-0 flex justify-content-lg-end justify-content-center">
							   <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal">
							   <i class="material-icons">&#xE147;</i>
							   <span>Agregar nuevos espacios</span>
							   </a>
							   <a href="#deleteEmployeeModal" class="btn btn-danger" data-toggle="modal">
							   <i class="material-icons">&#xE15C;</i>
							   <span>Eliminar</span>
							   </a>
							 </div>
					     </div>
					   </div>
					   <table class="table table-striped table-hover">
					      <thead>
						     <tr>
							 <th><span class="custom-checkbox">
							 <input type="checkbox" id="selectAll">
							
							 <th>Nombre sastreria</th>
							 <th>Necesidad</th>
							 <th>Producto</th>
							 <th>Numero de telefono</th>
							 <th>Descripcion del pedido</th>
							 <th>calendario</th>
							 
							 </tr>
						  </thead>
						  
						  <tbody>
						  <?php




$idsastrero=$_SESSION["id"];
$idsastreria="";

$verreservaregistrosastreria = "select * from registrosastreria where idsastrero='$idsastrero'";
$queryresultadoregistrosastreria = mysqli_query($servidor,$verreservaregistrosastreria);

while ($regreservaregistrosastreria = mysqli_fetch_array($queryresultadoregistrosastreria)){ 
$idsastreria=$regreservaregistrosastreria['id'];

}
echo "idsastreria".$idsastreria." idsastrero".$idsastrero;

                                //visualizacion
$verreserva = "select * from reservas where idsastreria='$idsastreria'";
$queryresultado = mysqli_query($servidor,$verreserva);

while ($regreserva = mysqli_fetch_array($queryresultado)){ 
	$idreserva=$regreserva['id'];
echo "entro";
                                ?>
						      <tr>
							 <th><span class="custom-checkbox">
							 <input type="checkbox" id="checkbox1" name="option[]" value="1">
							 <label for="checkbox1"></label></th>
							 <th>
							<?php
							$sasteria=$regreserva['idsastreria'];
						
							
							$versastrerias = "select * from registrosastreria where id='$sasteria'";
							$queryresultadosas = mysqli_query($servidor,$versastrerias);

							while ($regsastrerias = mysqli_fetch_array($queryresultadosas)){ 
								echo $regsastrerias['nombresastreria'];
							}
							 ?>	
							
							</th>
							 <th><?php echo $regreserva['idservicios'];?></th>
							 <th><?php echo $regreserva['idtipoprenda'];?></th>
							 <th><?php echo $regreserva['celular'];?></th>
							 <th><?php echo $regreserva['descripcion'];?></th>
							 <th><?php echo $regreserva['calendario'];?></th>
							 <th>
							    <a href="#editEmployeeModal" class="edit" data-toggle="modal">
							   <i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i>
							   </a>
							   <a href="#deleteEmployeeModal" class="delete" data-toggle="modal"  onclick="cargaid('<?php echo $idreserva;?>')">
							   <i class="material-icons" data-id="<?php echo  $regreserva['idservicios'];
							   
							   ?> 	 " title="Delete">&#xE872;</i>
							   </a>
							 </th>
							</tr>

							<?php
}

                                  ?>							 
							 
						  </tbody>
		
						  <script>
						
						function cargaid(id){
					
							$.ajax({
			url: 'eliminarreserva.php',
			type: 'POST',
			data: 'id='+id,
			success: function(result){
		
				location.reload();
			}
		})
						}
					   </script>				  
					      
					   </table>
					   
					   <div class="clearfix">
					     <div class="hint-text">Total<b> 5</b> paginas</div>
					     <ul class="pagination">
						    <li class="page-item disabled"><a href="#">Anterior</a></li>
							<li class="page-item "><a href="#"class="page-link">1</a></li>
							<li class="page-item "><a href="#"class="page-link">2</a></li>
							<li class="page-item active"><a href="#"class="page-link">3</a></li>
							<li class="page-item "><a href="#"class="page-link">4</a></li>
							<li class="page-item "><a href="#"class="page-link">5</a></li>
							<li class="page-item "><a href="#" class="page-link">Back</a></li>
						 </ul>
					   </div>
					   
					   
					   
					   
	
					   
					   
					   
					   
					   </div>
					</div>
					
					
									   
		<div class="modal fade" tabindex="-1" id="addEmployeeModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Agregar pedidos</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
		    <label>Nombre</label>
			<input type="text" class="form-control" required>
		</div>
		<div class="form-group">
		    <label>Email</label>
			<input type="emil" class="form-control" required>
		</div>
		<div class="form-group">
		    <label>Dirección</label>
			<textarea class="form-control" required></textarea>
		</div>
		<div class="form-group">
		    <label>Telefono</label>
			<input type="text" class="form-control" required>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-success">Agregar</button>
      </div>
    </div>
  </div>
</div>

					   
		<div class="modal fade" tabindex="-1" id="editEmployeeModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Editar información</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
		    <label>Nombre</label>
			<input type="text" class="form-control" required>
		</div>
		<div class="form-group">
		    <label>Email</label>
			<input type="emil" class="form-control" required>
		</div>
		<div class="form-group">
		    <label>Direccion</label>
			<textarea class="form-control" required></textarea>
		</div>
		<div class="form-group">
		    <label>Telefono</label>
			<input type="text" class="form-control" required>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-success">Guardar</button>
      </div>
    </div>
  </div>
</div>

					   
		<div class="modal fade" tabindex="-1" id="deleteEmployeeModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Eiminar pedido</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Estas seguro de eliminar este pedido</p>
		<p class="text-warning"><small>Esta accion es valida</small></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-success">Eliminar</button>
      </div>
    </div>
  </div>
</div>

					  
					
					
				 
			     </div>
			  </div>
		  
		 
		 <footer class="footer">
		    <div class="container-fluid">
			   <div class="footer-in">
			      <p class="mb-0">&copy 2024 Innovation System. Todos los derechos reservados.</p>
			   </div>
			</div>
		 </footer>
		 
		 
		 
		 
	  </div>
   
</div>




   <script src="js/jquery-3.3.1.slim.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/jquery-3.3.1.min.js"></script>
  
  
  <script type="text/javascript">
       $(document).ready(function(){
	      $(".xp-menubar").on('click',function(){
		    $("#sidebar").toggleClass('active');
			$("#content").toggleClass('active');
		  });
		  
		  $('.xp-menubar,.body-overlay').on('click',function(){
		     $("#sidebar,.body-overlay").toggleClass('show-nav');
		  });
		  
	   });




	 /*  $('.delete').on('click', function(){
		$.ajax({
			url: 'eliminar_reserva.php',
			type: 'POST',
			data: 'id='+$(this).data('id'),
			success: function(){
				alert("hola");
				//location.reload();
			}
		})
	   })*/
  </script>
  
  



  </body>
  
  </html>