<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir y Mostrar Foto</title>
</head>

<body>
    <h2>Subir y Mostrar Foto</h2>
    <?php
    // Comprobamos si se ha enviado una imagen
    if ($_FILES && isset($_FILES['foto'])) {
        $nombre_archivo = $_FILES['foto']['name'];
        $ruta_archivo = $_FILES['foto']['tmp_name'];
        $ruta_destino = 'uploads/' . $nombre_archivo;

        // Movemos la imagen a la carpeta de uploads
        if (move_uploaded_file($ruta_archivo, $ruta_destino)) {
            echo '<h3>Imagen subida exitosamente:</h3>';
            echo '<img src="' . $ruta_destino . '" alt="Foto">';
        } else {
            echo '<p>Ocurrió un error al subir la imagen.</p>';
        }
    }
    ?>

    <h3>Subir Foto</h3>
    <form action="fotos.html" method="post" enctype="multipart/form-data">
        <input type="file" name="foto">
        <button type="submit">Subir Foto</button>
    </form>
</body>

</html>
