<?php
include_once("productosagregados.php");

?>

<h2 id="uploadHeading">Sube Tu estampado</h2>
<img src="../logo aplicacion.png" alt="Logo de Modistería" style="width:150px;height:200px;position: fixed;top:20px;left:20px;z-index:9999999">
 
    <br>
<form action="insertarproductos.php" class="formProducts" enctype="multipart/form-data" method="post">
              
              <div class="ver">
                  <img id="imagenPrevisualizacion">
              </div>
        
      </div>
      <div class="opcionesSubirProducto">
        
          <div class="cmpText">
              <input type="text" name="marca" required placeholder="Nombre del estampado">
          </div>
          <div class="cmpText">
              <input type="number" name="precio" required placeholder="Precio">
          </div>
 
            
          <label>
              Agregar Foto<input type="file" class="editarbtn" multiple="multiple" name="fotico" id="fotico" accept=".jpg, .png, .jpeg">
          </label>
          <br><br>
          
          <div class="botones">
      <button class="button-73" role="button" name="subir" id="subir"><span class="text">Subir estampado</span></button>
      
</div>
      </div>
      
<br><br>
<style>
       
        
        body {
            background-image: url('fondosubir.jpg'); /* Agrega la URL de tu imagen */
            background-size: cover; /* Ajusta el tamaño de la imagen para cubrir toda la página */
            background-repeat: no-repeat; /* Evita que la imagen se repita */
            background-attachment: fixed; /* Fija la imagen en la ventana del navegador */
        }
        /* Estilo para el título centrado */
        .centered {
            text-align: center;
            margin-top: 20px; /* Ajusta el margen según sea necesario */
        }

        /* Estilo para el enlace "Atrás" */
        #atras-btn {
            position: fixed;
            bottom: 20px;
            right: 50px;
            background-color: coral;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        #atras-btn:hover {
            background-color: #ff8c00;
        }
    /* Style for the heading */
#uploadHeading {
    text-align: center; /* Center align the heading */
    color: white; /* Text color */
    font-family: Arial, sans-serif; /* Font family */
    font-size: 28px; /* Font size */
    margin-top: 50px; /* Add some top margin for spacing */
}






    .formProducts {
    width: 400px; /* Adjust width as needed */
    margin: 0 auto; /* Center the form horizontally */
    padding: 20px; /* Add some padding for spacing */
    border: 2px solid #ccc; /* Add a border */
    border-radius: 10px; /* Add border radius for rounded corners */
    background-color: #f9f9f9; /* Background color */
}

.ver {
    text-align: center; /* Center align the image */
    margin-bottom: 20px; /* Add some spacing below the image */
}

#imagenPrevisualizacion {
    max-width: 100%; /* Ensure the image doesn't overflow its container */
    height: auto; /* Maintain aspect ratio */
    border: 1px solid #ccc; /* Add a border around the image */
    border-radius: 5px; /* Add border radius for rounded corners */
}

.opcionesSubirProducto {
    display: flex; /* Use flexbox for layout */
    flex-direction: column; /* Arrange items in a column */
}

.cmpText {
    margin-bottom: 10px; /* Add some spacing between input fields */
}

input[type="text"],
input[type="number"] {
    width: 100%; /* Take up full width */
    padding: 10px; /* Add padding */
    border: 1px solid #ccc; /* Add border */
    border-radius: 5px; /* Add border radius for rounded corners */
    box-sizing: border-box; /* Ensure padding and border are included in width */
}

input[type="file"] {
    display: none; /* Hide the file input */
}

label {
    background-color: #f4af0d; /* Background color for label */
    color: #fff; /* Text color */
    padding: 10px 15px; /* Add padding */
    border-radius: 5px; /* Add border radius for rounded corners */
    cursor: pointer; /* Change cursor to pointer on hover */
    text-align: center; /* Center align text */
    display: inline-block; /* Make label inline-block */
}

label:hover {
    background-color: #f4af0d; /* Darken background color on hover */
}

    /* Style for form container */
    .formContainer {
        width: 400px;
        margin: auto;
    }

    /* Style for image preview */
    .ver {
        margin-bottom: 20px;
    }

    #imagenPrevisualizacion {
        max-width: 100%;
        height: auto;
    }

    /* Style for form inputs */
    .opcionesSubirProducto {
        display: flex;
        flex-direction: column;
    }

    .cmpText {
        margin-bottom: 10px;
    }

    input[type="text"],
    input[type="number"] {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
        font-size: 16px;
    }

    input[type="file"] {
        margin-bottom: 10px;
    }

    /* Style for submit button */
    .submitBtn {
        background-color: #4caf50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }

    .submitBtn:hover {
        background-color: #45a049;
    }
       /* Style for the button */
       .button-73 {
        background-color: #007bff; /* Background color */
        color: #fff; /* Text color */
        padding: 10px 20px; /* Padding */
        border: none; /* Remove border */
        border-radius: 5px; /* Border radius for rounded corners */
        cursor: pointer; /* Cursor style */
        font-size: 16px; /* Font size */
        transition: background-color 0.3s ease; /* Smooth transition for background color */
    }

    .button-73:hover {
        background-color: #0056b3; /* Darker background color on hover */
    }

    .button-73:focus {
        outline: none; /* Remove outline on focus */
    }

    /* Style for the button text */
   
       
    </style>
 <!--     <input type="submit" value="Subir">-->


</form>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/productos.css"> <!-- llamando al diseñador-->
    <script src="../js/jquery-3.2.1.min.js"></script><!-- llamando a la librería de comandos query-->
</head>
<body>

<!-- formulario para agregar productos y abre el archivo insertarproductos.php-->


<br><br><br>

<!-- buscar productos por categoría, para este ejercicio se emplea el AJAX en la parte inferior y se debe incluir en archivos el 
jquery-3.2.1.min.js -->

</head>

<body>
<style>
    .centered {
        text-align: center;
    }
</style>
</head>
<body>
<div class="centered">
    <br><br><br>
    <h2> Aqui puedes ver como quedaran los estampados</h2>
</div>
    <a href="administradoroficial.php" id="atras-btn">Atrás</a>
  

    <style>  
      h2 {
            color: white; /* Color de texto blanco para h2 */
        }
  #atras-btn {
               position: fixed;
               bottom: 20px;
               right: 50px;
               background-color: coral;
               color: white;
               border: none;
               border-radius: 5px;
               padding: 10px 20px;
               font-size: 18px;
               cursor: pointer;
               box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
             }  #atras-btn:hover {
               background-color: #ff8c00;
             }
             </style>
   


      
<!-- Aquí se muestran los productos agregados, utilizando un ciclo while, el cual deja 3 productos por fila-->
         


<style>
    
 .contenedor_columna {
    width: 300px; /* Ancho fijo para todos los contenedores de producto */
    height: 400px; /* Altura fija para todos los contenedores de producto */
    text-align: center;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease;
    margin: 20px; /* Espaciado entre los contenedores */
}

.contenedor_columna:hover {
    transform: translateY(-5px);
}

.image {
    position: relative;
    width: 100%; /* Ajusta el ancho de la imagen al 100% del contenedor */
    height: 60%; /* Altura relativa para la imagen */
    overflow: hidden;
}

.image img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover; /* Ajusta el tamaño de la imagen para que cubra completamente su contenedor */
}
weight: bold;
}

.precio {
    font-size: 16px;
    color: #666;
}


        #atras-btn {
            position: fixed;
            bottom: 20px;
            right: 50px;
            background-color: coral;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            text-decoration: none;
        }

        #atras-btn:hover {
            background-color: #ff8c00;
        }

          
        body {
            background-image: url('../fondosubir.jpg'); /* Agrega la URL de tu imagen */
            background-size: cover; /* Ajusta el tamaño de la imagen para cubrir toda la página */
            background-repeat: no-repeat; /* Evita que la imagen se repita */
            background-attachment: fixed; /* Fija la imagen en la ventana del navegador */
        }
 </style>

<?php 
$r = 0;
echo '<table id="contenedor_producto"><tr>';

while ($row = mysqli_fetch_assoc($result)) {
    echo '<td>
            <div class="contenedor_columna">
                <div class="image">
                    <img src="' . $row['foto'] . '" alt="">
                </div>
                
                <div class="marquita">
                    <h3>' . $row['Marca'] . '</h3>
                </div>
                <div class="precio">
                    <h3>$ ' . $row['valor'] . '</h3>
                </div>
            </div>
          </td>';
    $r++;
    if ($r == 3) {
        echo '</tr><tr>';
        $r = 0;
    }
} 
echo '</tr></table>';
?>


</body>
</html>
<!-- Este AJAX está creado para la búsqueda y abre el archivo busquedaproductos.php-->
<script>
        $(document).ready(function(){
            $('#search').keyup(function(){
                var query = $(this).val();
                if(query != '')
                {
                    $.ajax({
                        url:"busquedaproductos.php",
                        method:"POST",
                        data:{query:query},
                        success:function(data)
                        {
                            $('#contenedor_producto').html(data);
                        }
                    });
                }
             else{
                $.ajax({
                        url:"busquedaproductos.php",
                        method:"POST",
                        data:{query:''},
                        success:function(data)
                        {
                            $('#contenedor_producto').html(data);
                        }
                    });
           
            }
              
                
            });
        });
    </script>


<!-- Este AJAX está creado para realizar la busqueda de marcas busquedaproductos.php-->
<script>
        $(document).ready(function(){
            $('#marcas').change(function(){
                var seleccion = $(this).val();
                if(seleccion != '')
                {
                    $.ajax({
                        url:"busquedaproductos.php",
                        method:"POST",
                        data:{seleccion:seleccion},
                        success:function(data)
                        {
                            $('#contenedor_producto').html(data);
                        }
                    });
                }
             else{
                $.ajax({
                        url:"busquedaproductos.php",
                        method:"POST",
                        data:{seleccion:''},
                        success:function(data)
                        {
                            $('#contenedor_producto').html(data);
                        }
                    });
           
            }
              
                
            });
        });
    </script>
   