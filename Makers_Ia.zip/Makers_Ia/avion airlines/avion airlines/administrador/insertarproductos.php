<?php

$conexion = mysqli_connect('localhost', 'root', '', 'system innovation');
if(isset($_POST['subir'])){
$idProducto = $_POST['codigoProducto'];
$proveedor = $_POST['proveedor'];
$marca = $_POST['marca'];
$precio = $_POST['precio'];

$fotoProducto = $_FILES['fotico'];

$nombre_img = $_FILES['fotico']['name'];
$temporal = $_FILES['fotico']['tmp_name'];
echo $temporal;
$carpeta = 'fotos';
$ruta = $carpeta . '/' . $nombre_img;
echo $ruta;

move_uploaded_file($temporal, $carpeta . '/' . $nombre_img);

$select = "SELECT * FROM productos WHERE CodigoProducto = '$idProducto'";
$result = mysqli_query($conexion, $select);

if(mysqli_num_rows($result)>0){
    echo '<script>
            alert("Producto ya registrado");
            window.history.go(-1);
        </script>';
}else{
    $insert = "INSERT INTO productos(CodigoProducto, valor, Proveedor, Marca, foto) VALUES ('$idProducto', '$precio', '$proveedor', '$marca', '$ruta')";
    mysqli_query($conexion, $insert);
    header('location: imagen_subir.php');
}
}
?>
