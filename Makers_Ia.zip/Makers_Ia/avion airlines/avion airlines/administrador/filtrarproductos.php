<?php

$conexion = mysqli_connect('localhost', 'root', '', 'paraiso_astral');

$select = "SELECT Marca FROM productos"; 

$resultado = mysqli_query($conexion, $select);

if(mysqli_num_rows($resultado) > 0)
    {
     
  
        while($data = mysqli_fetch_assoc($resultado))
        {
            
                echo '
                <option>
                ' . $data['Marca'] . '
            
            </option>';
           
        }
       
    }
   
     
       
 
   

?>