

<?php
session_start();
$conexion = mysqli_connect('localhost', 'root', '', 'paraiso_astral');
$select = "SELECT * FROM productos";
$result = $conexion->query($select);

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir imagen</title>
</head>
<body>
    <form action="insertarproductos.php" method="post" enctype="multipart/form-data">
 
    </form>
</body>
</html>
