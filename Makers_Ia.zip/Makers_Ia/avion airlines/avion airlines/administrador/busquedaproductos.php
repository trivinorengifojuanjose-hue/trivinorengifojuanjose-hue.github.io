<?php
$conexion = mysqli_connect('localhost', 'root', '', 'paraiso_astral');
$output = '';

if(isset($_POST['query']))
{

    $search = $_POST['query'];
  
    $query = "SELECT * FROM productos WHERE Marca LIKE '%".$search."%'";
    $resultado = mysqli_query($conexion, $query);

    if(mysqli_num_rows($resultado) > 0)
    {
        $r=0;
            echo 
           '<table class="contenedor_producto">
            <tr>';
        while($data = mysqli_fetch_assoc($resultado))
        {
            
                echo '
                <td>
                <div class="contenedor_columna">
                <div class="image">
                    <img src="' . $data['foto'] . '" alt="">
                </div>
                
                <div class="marquita">
                    <h3>' . $data['Marca'] . '</h3>
                </div>
                <div class="precio">
                    <h3>$ ' . $data['valor'] . '</h3>
                </div>
                </div>
            
            </td>';
            $r++;
             if($r==3)
             {
                echo '<tr>';
                $r=0;
            }

        }
        echo '</tr> </table>';
    }
     else
     {
        $output .= 'No se encontraron resultados';
     }
     
       
 
    echo $output;
}


if(isset($_POST['seleccion']))
{

    $marca = $_POST['seleccion'];
  
    $query = "SELECT * FROM productos WHERE Marca ='$marca'";
    $resultado = mysqli_query($conexion, $query);

    if(mysqli_num_rows($resultado) > 0)
    {
        $r=0;
            echo 
           '<table class="contenedor_producto">
            <tr>';
        while($data = mysqli_fetch_assoc($resultado))
        {
            
                echo '
                <td>
                <div class="contenedor_columna">
                <div class="image">
                    <img src="' . $data['foto'] . '" alt="">
                </div>
                
                <div class="marquita">
                    <h3>' . $data['Marca'] . '</h3>
                </div>
                <div class="precio">
                    <h3>$ ' . $data['valor'] . '</h3>
                </div>
                </div>
            
            </td>';
            $r++;
             if($r==3)
             {
                echo '<tr>';
                $r=0;
            }

        }
        echo '</tr> </table>';
    }
     else
     {
        $output .= 'No se encontraron resultados';
     }
     
       
 
    echo $output;
}


?>