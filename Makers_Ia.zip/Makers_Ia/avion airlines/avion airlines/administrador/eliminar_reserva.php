<?php

$servidor=mysqli_connect("localhost","root","") or die ("Imposible conectar con el servidor");
$db = "system innovation"; //Base de datos
$conexion= mysqli_select_db($servidor,$db);


$id = $_GET['id'];
echo $id;
$sql = "DELETE FROM reservas WHERE id='$id'";
$queryresultado = mysqli_query($servidor,$sql);

?>