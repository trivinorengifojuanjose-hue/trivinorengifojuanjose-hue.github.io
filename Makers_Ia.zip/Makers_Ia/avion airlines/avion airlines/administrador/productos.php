<?php
include_once("productosagregados.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/productos.css"> <!-- llamando al diseñador-->
    <script src="../js/jquery-3.2.1.min.js"></script><!-- llamando a la librería de comandos query-->
</head>
<body>



<style>
    
 .contenedor_columna {
    width: 300px; /* Ancho fijo para todos los contenedores de producto */
    height: 400px; /* Altura fija para todos los contenedores de producto */
    text-align: center;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease;
    margin: 20px; /* Espaciado entre los contenedores */
}

.contenedor_columna:hover {
    transform: translateY(-5px);
}

.image {
    position: relative;
    width: 100%; /* Ajusta el ancho de la imagen al 100% del contenedor */
    height: 60%; /* Altura relativa para la imagen */
    overflow: hidden;
}

.image img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover; /* Ajusta el tamaño de la imagen para que cubra completamente su contenedor */
}
weight: bold;
}

.precio {
    font-size: 16px;
    color: #666;
}


        #atras-btn {
            position: fixed;
            bottom: 20px;
            right: 50px;
            background-color: coral;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            text-decoration: none;
        }

        #atras-btn:hover {
            background-color: #ff8c00;
        }

          
        body {
            background-image: url('../fondoproductos.jpg'); /* Agrega la URL de tu imagen */
            background-size: cover; /* Ajusta el tamaño de la imagen para cubrir toda la página */
            background-repeat: no-repeat; /* Evita que la imagen se repita */
            background-attachment: fixed; /* Fija la imagen en la ventana del navegador */
        }
 </style>
</head>

<body>
  
    <a href="../administracion.php" id="atras-btn">Atrás</a>
  
    <div class="titulo">Estampados y sus precios</div>
<style>
    .titulo {
        text-align: center;
        font-size: 36px;
        font-weight: bold;
        color: #333;
        text-shadow: 2px 2px 2px #ddd;
        margin-bottom: 30px;
    }
  
      
.producto-imagen {
    transition: transform 0.3s ease; 
}


.producto-imagen:hover {
    transform: scale(1.1); 
}

</style>


      
<!-- Aquí se muestran los productos agregados, utilizando un ciclo while, el cual deja 3 productos por fila-->
         

            <?php $r=0;
            echo 
            '
            <table id="contenedor_producto">
            <tr>';
            while ($row = mysqli_fetch_assoc($result)) {
    
                echo '
                <td>
                <div class="contenedor_columna">
                <div class="image">
                    <img src="' . $row['foto'] . '" alt="">
                </div>
                
                <div class="marquita">
                    <h3>' . $row['Marca'] . '</h3>
                </div>
                <div class="precio">
                    <h3>$ ' . $row['valor'] . '</h3>
                </div>
                </div>
            
            </td>';
            $r++;
             if($r==3){
                echo '<tr>';
                $r=0;
            }

            } echo '</tr> </table>';
            ?>
     
<style>.producto-imagen {
    transition: transform 0.3s ease; 
}


.producto-imagen:hover {
    transform: scale(1.1); 
}</style>

<!-- Este AJAX está creado para la búsqueda y abre el archivo busquedaproductos.php-->
<script>
        $(document).ready(function(){
            $('#search').keyup(function(){
                var query = $(this).val();
                if(query != '')
                {
                    $.ajax({
                        url:"busquedaproductos.php",
                        method:"POST",
                        data:{query:query},
                        success:function(data)
                        {
                            $('#contenedor_producto').html(data);
                        }
                    });
                }
             else{
                $.ajax({
                        url:"busquedaproductos.php",
                        method:"POST",
                        data:{query:''},
                        success:function(data)
                        {
                            $('#contenedor_producto').html(data);
                        }
                    });
           
            }
              
                
            });
        });
    </script>


<!-- Este AJAX está creado para realizar la busqueda de marcas busquedaproductos.php-->
<script>
        $(document).ready(function(){
            $('#marcas').change(function(){
                var seleccion = $(this).val();
                if(seleccion != '')
                {
                    $.ajax({
                        url:"busquedaproductos.php",
                        method:"POST",
                        data:{seleccion:seleccion},
                        success:function(data)
                        {
                            $('#contenedor_producto').html(data);
                        }
                    });
                }
             else{
                $.ajax({
                        url:"busquedaproductos.php",
                        method:"POST",
                        data:{seleccion:''},
                        success:function(data)
                        {
                            $('#contenedor_producto').html(data);
                        }
                    });
           
            }
              
                
            });
        });
    </script>
    
    </body>
</html>