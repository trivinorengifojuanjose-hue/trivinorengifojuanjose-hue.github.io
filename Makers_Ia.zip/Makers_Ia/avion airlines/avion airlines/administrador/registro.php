<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Registrar sastreria</title>
    <link rel="stylesheet" href="css/registro.css">
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="content">
      <div class="left-side">
        <div class="address details">
          <i class="fas fa-map-marker-alt"></i>
          <div class="topic">Dirección</div>
        </div>
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Telefono</div>
        </div>
        <div class="email details">
          <i class="fas fa-envelope"></i>
          <div class="topic">Nombre</div>
        </div>
      </div>
      <div class="right-side">
        <div class="topic-text">Registra tu sastreria</div>
        <p>Con solo un click tu sastreria ya estara registrada</p>
      <form action="../insertarsastreria.php" method="post">
        <div class="input-box">
          <input type="text" name="nombresastreria" placeholder="Escribe tu nombre">
        </div>
        <div class="input-box">
          <input type="text" name="direccion"  placeholder="Escribe la ubicacion de tu sastreria">
        </div>
        <div class="input-box">
          <input type="text" name="celulardellocal" placeholder="Escribe tu número de telefono">
        </div>
        <div class="input-box">
          <input type="text" name="coordenadas" placeholder="Coordenadas">
</div>
        <div class="input-box message-box">
          
        </div>
        <a href="administradoroficial.php" id="atras-btn">atras</a>
  <style>    #atras-btn {
    position: absolute;
    bottom: 20px; /* Ajusta esta distancia según tu preferencia */
    right: 50px; /* Ajusta esta distancia según tu preferencia */
    background-color: coral;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  }
  #atras-btn:hover {
    background-color: #ff8c00;
  }
  
        <style>
  .button {
    border: none;
    overflow: hidden;
    position: relative;
    display: inline-block;
  }
  
  body {
            background-image: url('../fondosastrerias.jpg'); /* Agrega la URL de tu imagen */
            background-size: cover; /* Ajusta el tamaño de la imagen para cubrir toda la página */
            background-repeat: no-repeat; /* Evita que la imagen se repita */
            background-attachment: fixed; /* Fija la imagen en la ventana del navegador */
        }
  input[type="submit"] {
    background: linear-gradient(to right, blue, #18a6ca);
    border: none;
    border-radius: 25px;
    color: #fff;
    padding: 15px 30px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 16px;
    font-weight: bold;
  }

  .button:hover::before {
    transform: scale(2);
    opacity: 0;
  }
</style>

<div class="button">
  <input type="submit" value="Registrarme">

</div>

      </form>
    </div>
    </div>
  </div>
</body>
</html>